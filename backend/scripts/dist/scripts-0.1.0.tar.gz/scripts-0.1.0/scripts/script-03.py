# import pyautogui
# import json

# pyautogui.hotkey('ctrl', 't')
# pyautogui.write('www.netflix.com.br')
# pyautogui.press('enter')

# print(json.dumps('Ação Executada!'))
import json
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
from selenium.webdriver.chrome.options import Options

client = webdriver.Chrome()

client.get("https://www.google.com/")

client.find_element('xpath', '/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input').send_keys('cotação dolar')

client.find_element('xpath', '/html/body/div[1]/div[3]/form/div[1]/div[1]/div[1]/div/div[2]/input').send_keys(Keys.ENTER)

time.sleep(10)

print(json.dumps('Código Executado!'))