# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['scripts']

package_data = \
{'': ['*']}

install_requires = \
['selenium>=4.8.0,<5.0.0']

setup_kwargs = {
    'name': 'scripts',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'João Vitor Denari dos Santos',
    'author_email': '98748740+jdenari@users.noreply.github.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
